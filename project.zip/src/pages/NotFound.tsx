import React from 'react';
import Button from '../components/ui/Button';
import { Home, ArrowLeft } from 'lucide-react';

const NotFound: React.FC = () => {
  return (
    <div className="min-h-[80vh] flex flex-col items-center justify-center text-center px-4">
      <h1 className="text-9xl font-bold text-blue-600 dark:text-blue-400">404</h1>
      <h2 className="text-3xl md:text-4xl font-bold mt-6 mb-4 text-gray-900 dark:text-white">
        Page non trouvée
      </h2>
      <p className="text-lg text-gray-600 dark:text-gray-400 max-w-md mb-8">
        La page que vous recherchez n'existe pas ou a été déplacée.
      </p>
      <div className="flex flex-col sm:flex-row gap-4">
        <Button 
          to="/" 
          variant="primary"
          icon={<Home size={20} />}
        >
          Retour à l'accueil
        </Button>
        <Button 
          onClick={() => window.history.back()}
          variant="outline"
          icon={<ArrowLeft size={20} />}
        >
          Page précédente
        </Button>
      </div>
    </div>
  );
};

export default NotFound;