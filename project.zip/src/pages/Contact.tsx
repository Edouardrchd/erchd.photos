import React, { useState } from 'react';
import Section from '../components/ui/Section';
import Button from '../components/ui/Button';
import { Mail, Phone, MapPin, Send, CheckCircle } from 'lucide-react';

const Contact: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });
  
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  
  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    
    if (!formData.name.trim()) {
      newErrors.name = 'Le nom est requis';
    }
    
    if (!formData.email.trim()) {
      newErrors.email = 'L\'email est requis';
    } else if (!/^\S+@\S+\.\S+$/.test(formData.email)) {
      newErrors.email = 'Email invalide';
    }
    
    if (!formData.subject.trim()) {
      newErrors.subject = 'Le sujet est requis';
    }
    
    if (!formData.message.trim()) {
      newErrors.message = 'Le message est requis';
    } else if (formData.message.length < 20) {
      newErrors.message = 'Le message doit comporter au moins 20 caractères';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    
    // Clear error when user types
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (validateForm()) {
      setIsSubmitting(true);
      
      // Simulate API call
      setTimeout(() => {
        setIsSubmitting(false);
        setIsSubmitted(true);
        setFormData({
          name: '',
          email: '',
          subject: '',
          message: ''
        });
      }, 1500);
    }
  };

  const contactInfo = [
    {
      icon: <Mail size={24} className="text-blue-600 dark:text-blue-400" />,
      title: "Email",
      value: "contact@monportfolio.com"
    },
    {
      icon: <Phone size={24} className="text-blue-600 dark:text-blue-400" />,
      title: "Téléphone",
      value: "+33 1 23 45 67 89"
    },
    {
      icon: <MapPin size={24} className="text-blue-600 dark:text-blue-400" />,
      title: "Adresse",
      value: "Paris, France"
    }
  ];

  return (
    <>
      {/* Hero Section */}
      <section className="relative pt-20 pb-24 flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img
            src="https://images.pexels.com/photos/1552617/pexels-photo-1552617.jpeg?auto=compress&cs=tinysrgb&w=1600"
            alt="Contact Hero"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-black bg-opacity-70"></div>
        </div>
        
        <div className="container mx-auto px-4 relative z-10 text-center">
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-6 tracking-tight">
            Contact
          </h1>
          <p className="text-xl text-gray-200 mb-6 max-w-2xl mx-auto">
            N'hésitez pas à me contacter pour discuter de vos projets
          </p>
        </div>
      </section>

      {/* Contact Section */}
      <Section>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Contact Info */}
          <div>
            <h2 className="text-2xl md:text-3xl font-bold mb-6 text-gray-900 dark:text-white">
              Restons en contact
            </h2>
            <p className="text-gray-700 dark:text-gray-300 mb-8 leading-relaxed">
              Vous êtes intéressé par une collaboration ou vous avez des questions sur mes services ? 
              N'hésitez pas à me contacter. Je serais ravi de discuter de votre projet et de voir 
              comment je peux vous aider.
            </p>
            
            <div className="space-y-6 mb-8">
              {contactInfo.map((info, index) => (
                <div key={index} className="flex items-start">
                  <div className="p-3 bg-blue-100 dark:bg-blue-900/30 rounded-full mr-4">
                    {info.icon}
                  </div>
                  <div>
                    <h3 className="font-medium text-gray-900 dark:text-white mb-1">
                      {info.title}
                    </h3>
                    <p className="text-gray-600 dark:text-gray-400">
                      {info.value}
                    </p>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="p-6 bg-gray-50 dark:bg-gray-800 rounded-lg">
              <h3 className="text-xl font-semibold mb-4 text-gray-900 dark:text-white">
                Horaires de disponibilité
              </h3>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-gray-600 dark:text-gray-400">Lundi - Vendredi:</span>
                  <span className="font-medium text-gray-900 dark:text-white">9h - 18h</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600 dark:text-gray-400">Samedi:</span>
                  <span className="font-medium text-gray-900 dark:text-white">10h - 16h</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600 dark:text-gray-400">Dimanche:</span>
                  <span className="font-medium text-gray-900 dark:text-white">Fermé</span>
                </div>
              </div>
            </div>
          </div>
          
          {/* Contact Form */}
          <div className="bg-white dark:bg-gray-800 rounded-xl p-6 md:p-8 shadow-md">
            {!isSubmitted ? (
              <>
                <h2 className="text-2xl font-bold mb-6 text-gray-900 dark:text-white">
                  Envoyez-moi un message
                </h2>
                <form onSubmit={handleSubmit}>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                    <div>
                      <label htmlFor="name" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                        Nom complet <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="text"
                        id="name"
                        name="name"
                        value={formData.name}
                        onChange={handleChange}
                        className={`w-full px-4 py-2 rounded-lg border ${
                          errors.name 
                            ? 'border-red-500 focus:ring-red-500 focus:border-red-500' 
                            : 'border-gray-300 dark:border-gray-600 focus:ring-blue-500 focus:border-blue-500'
                        } bg-white dark:bg-gray-700 text-gray-900 dark:text-white`}
                        placeholder="Votre nom"
                      />
                      {errors.name && (
                        <p className="mt-1 text-sm text-red-500">{errors.name}</p>
                      )}
                    </div>
                    <div>
                      <label htmlFor="email" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                        Email <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="email"
                        id="email"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                        className={`w-full px-4 py-2 rounded-lg border ${
                          errors.email 
                            ? 'border-red-500 focus:ring-red-500 focus:border-red-500' 
                            : 'border-gray-300 dark:border-gray-600 focus:ring-blue-500 focus:border-blue-500'
                        } bg-white dark:bg-gray-700 text-gray-900 dark:text-white`}
                        placeholder="Votre email"
                      />
                      {errors.email && (
                        <p className="mt-1 text-sm text-red-500">{errors.email}</p>
                      )}
                    </div>
                  </div>
                  
                  <div className="mb-6">
                    <label htmlFor="subject" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                      Sujet <span className="text-red-500">*</span>
                    </label>
                    <select
                      id="subject"
                      name="subject"
                      value={formData.subject}
                      onChange={handleChange}
                      className={`w-full px-4 py-2 rounded-lg border ${
                        errors.subject 
                          ? 'border-red-500 focus:ring-red-500 focus:border-red-500' 
                          : 'border-gray-300 dark:border-gray-600 focus:ring-blue-500 focus:border-blue-500'
                      } bg-white dark:bg-gray-700 text-gray-900 dark:text-white`}
                    >
                      <option value="">Sélectionnez un sujet</option>
                      <option value="Collaboration">Collaboration</option>
                      <option value="Projet Photo">Projet Photo</option>
                      <option value="Événement Sportif">Événement Sportif</option>
                      <option value="Question Générale">Question Générale</option>
                      <option value="Autre">Autre</option>
                    </select>
                    {errors.subject && (
                      <p className="mt-1 text-sm text-red-500">{errors.subject}</p>
                    )}
                  </div>
                  
                  <div className="mb-6">
                    <label htmlFor="message" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                      Message <span className="text-red-500">*</span>
                    </label>
                    <textarea
                      id="message"
                      name="message"
                      rows={5}
                      value={formData.message}
                      onChange={handleChange}
                      className={`w-full px-4 py-2 rounded-lg border ${
                        errors.message 
                          ? 'border-red-500 focus:ring-red-500 focus:border-red-500' 
                          : 'border-gray-300 dark:border-gray-600 focus:ring-blue-500 focus:border-blue-500'
                      } bg-white dark:bg-gray-700 text-gray-900 dark:text-white`}
                      placeholder="Votre message"
                    />
                    {errors.message && (
                      <p className="mt-1 text-sm text-red-500">{errors.message}</p>
                    )}
                  </div>
                  
                  <Button 
                    type="submit" 
                    variant="primary" 
                    fullWidth 
                    disabled={isSubmitting}
                    icon={isSubmitting ? null : <Send size={18} />}
                    className="py-3"
                  >
                    {isSubmitting ? 'Envoi en cours...' : 'Envoyer le message'}
                  </Button>
                </form>
              </>
            ) : (
              <div className="text-center py-10">
                <div className="flex justify-center mb-4">
                  <CheckCircle size={60} className="text-green-500" />
                </div>
                <h2 className="text-2xl font-bold mb-4 text-gray-900 dark:text-white">
                  Message envoyé avec succès !
                </h2>
                <p className="text-gray-600 dark:text-gray-400 mb-8">
                  Merci pour votre message. Je vous répondrai dans les plus brefs délais.
                </p>
                <Button 
                  onClick={() => setIsSubmitted(false)} 
                  variant="outline"
                >
                  Envoyer un autre message
                </Button>
              </div>
            )}
          </div>
        </div>
      </Section>

      {/* Map Section */}
      <Section className="pb-0">
        <div className="h-[400px] w-full rounded-t-xl overflow-hidden shadow-md">
          <img 
            src="https://images.pexels.com/photos/4388593/pexels-photo-4388593.jpeg?auto=compress&cs=tinysrgb&w=1600" 
            alt="Map Location" 
            className="w-full h-full object-cover"
          />
        </div>
      </Section>
    </>
  );
};

export default Contact;