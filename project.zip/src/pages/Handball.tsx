import React from 'react';
import Section from '../components/ui/Section';
import Card, { CardImage, CardBody, CardTitle } from '../components/ui/Card';
import { Calendar, MapPin, Award, Clock } from 'lucide-react';

const Handball: React.FC = () => {
  const events = [
    {
      id: 1,
      title: "Championnat de France",
      image: "https://images.pexels.com/photos/3654861/pexels-photo-3654861.jpeg?auto=compress&cs=tinysrgb&w=1600",
      date: "20 Mai 2025",
      location: "AccorHotels Arena, Paris",
      description: "Couverture photographique de la finale du championnat de France de handball."
    },
    {
      id: 2,
      title: "Tournoi International",
      image: "https://images.pexels.com/photos/1618269/pexels-photo-1618269.jpeg?auto=compress&cs=tinysrgb&w=1600",
      date: "5 Août 2025",
      location: "Stade Pierre Mauroy, Lille",
      description: "Photographies du tournoi international opposant la France, le Danemark, l'Espagne et l'Allemagne."
    }
  ];

  const stats = [
    { value: "45+", label: "Matchs couverts", icon: <Clock size={24} className="mb-2 text-emerald-500" /> },
    { value: "8", label: "Clubs partenaires", icon: <Award size={24} className="mb-2 text-emerald-500" /> },
    { value: "3", label: "Coupes nationales", icon: <Trophy size={24} className="mb-2 text-emerald-500" /> },
    { value: "12K+", label: "Photos prises", icon: <Camera size={24} className="mb-2 text-emerald-500" /> }
  ];

  const photos = [
    "https://images.pexels.com/photos/3654861/pexels-photo-3654861.jpeg?auto=compress&cs=tinysrgb&w=1600",
    "https://images.pexels.com/photos/1618269/pexels-photo-1618269.jpeg?auto=compress&cs=tinysrgb&w=1600",
    "https://images.pexels.com/photos/163444/sport-treadmill-tor-route-163444.jpeg?auto=compress&cs=tinysrgb&w=1600",
    "https://images.pexels.com/photos/711187/pexels-photo-711187.jpeg?auto=compress&cs=tinysrgb&w=1600"
  ];

  return (
    <>
      {/* Hero Section */}
      <section className="relative pt-20 pb-32 flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img
            src="https://images.pexels.com/photos/3654861/pexels-photo-3654861.jpeg?auto=compress&cs=tinysrgb&w=1600"
            alt="Handball Hero"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-black bg-opacity-70"></div>
        </div>
        
        <div className="container mx-auto px-4 relative z-10 text-center">
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-6 tracking-tight">
            Handball
          </h1>
          <p className="text-xl text-gray-200 mb-6 max-w-2xl mx-auto">
            L'intensité et la précision du handball à travers mon objectif
          </p>
        </div>
      </section>

      {/* Introduction Section */}
      <Section>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div>
            <img 
              src="https://images.pexels.com/photos/1618269/pexels-photo-1618269.jpeg?auto=compress&cs=tinysrgb&w=1600" 
              alt="Handball Photography"
              className="rounded-xl shadow-lg w-full h-auto object-cover" 
            />
          </div>
          <div>
            <h2 className="text-3xl font-bold mb-6 text-gray-900 dark:text-white">
              Ma Passion pour le Handball
            </h2>
            <p className="text-gray-700 dark:text-gray-300 mb-6 leading-relaxed">
              Le handball est un sport d'une intensité rare, combinant vitesse, précision et tactique. 
              En tant que photographe, j'ai toujours été fasciné par la dynamique de ce jeu et les émotions 
              qu'il génère, tant sur le terrain que dans les gradins.
            </p>
            <p className="text-gray-700 dark:text-gray-300 mb-6 leading-relaxed">
              Depuis plusieurs années, je suis les principales compétitions françaises et européennes, 
              collaborant avec différents clubs et médias pour offrir un regard unique sur ce sport. 
              Chaque match est une nouvelle occasion de capturer l'essence de ce jeu passionnant.
            </p>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-8">
              {stats.map((stat, index) => (
                <div key={index} className="text-center">
                  {stat.icon}
                  <div className="text-2xl font-bold text-gray-900 dark:text-white">{stat.value}</div>
                  <div className="text-sm text-gray-600 dark:text-gray-400">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </Section>

      {/* Photo Gallery */}
      <Section title="Galerie Handball" className="bg-gray-50 dark:bg-gray-800">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          {photos.map((photo, index) => (
            <div key={index} className="overflow-hidden rounded-lg shadow-md transition-transform duration-300 hover:-translate-y-2 aspect-[4/3]">
              <img 
                src={photo} 
                alt={`Handball photo ${index + 1}`} 
                className="w-full h-full object-cover transition-transform duration-500 hover:scale-110"
              />
            </div>
          ))}
        </div>
      </Section>

      {/* Events Section */}
      <Section title="Événements Handball" subtitle="Découvrez les événements que j'ai couvert et ceux à venir">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {events.map(event => (
            <Card key={event.id} hover>
              <CardImage src={event.image} alt={event.title} />
              <CardBody>
                <CardTitle>{event.title}</CardTitle>
                <div className="mb-4 space-y-2">
                  <div className="flex items-center text-gray-600 dark:text-gray-400">
                    <Calendar size={16} className="mr-2" />
                    {event.date}
                  </div>
                  <div className="flex items-center text-gray-600 dark:text-gray-400">
                    <MapPin size={16} className="mr-2" />
                    {event.location}
                  </div>
                </div>
                <p className="text-gray-600 dark:text-gray-400 mb-4">
                  {event.description}
                </p>
              </CardBody>
            </Card>
          ))}
        </div>
      </Section>

      {/* Quote Section */}
      <section className="py-24 bg-emerald-600">
        <div className="container mx-auto px-4 text-center">
          <blockquote className="max-w-4xl mx-auto">
            <p className="text-2xl md:text-3xl text-white mb-8 italic">
              "Le handball est comme une danse collective où chaque mouvement compte. Mon appareil photo tente de saisir cette chorégraphie unique."
            </p>
            <footer className="text-emerald-200">
              <cite>— Ma vision photographique</cite>
            </footer>
          </blockquote>
        </div>
      </section>
    </>
  );
};

export default Handball;