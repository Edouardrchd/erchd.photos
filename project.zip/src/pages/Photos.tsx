import React, { useState } from 'react';
import Section from '../components/ui/Section';
import Button from '../components/ui/Button';
import { Camera, ZoomIn } from 'lucide-react';

const Photos: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [modalImage, setModalImage] = useState<string | null>(null);
  
  const categories = [
    { id: 'all', name: 'Tout' },
    { id: 'football', name: 'Football' },
    { id: 'basketball', name: 'Basketball' },
    { id: 'handball', name: 'Handball' },
    { id: 'other', name: 'Autres' }
  ];
  
  const photos = [
    { id: 1, src: 'https://images.pexels.com/photos/47730/the-ball-stadion-football-the-pitch-47730.jpeg?auto=compress&cs=tinysrgb&w=1600', category: 'football', alt: 'Football match' },
    { id: 2, src: 'https://images.pexels.com/photos/3755440/pexels-photo-3755440.jpeg?auto=compress&cs=tinysrgb&w=1600', category: 'football', alt: 'Football player' },
    { id: 3, src: 'https://images.pexels.com/photos/2824133/pexels-photo-2824133.jpeg?auto=compress&cs=tinysrgb&w=1600', category: 'basketball', alt: 'Basketball player dunking' },
    { id: 4, src: 'https://images.pexels.com/photos/358042/pexels-photo-358042.jpeg?auto=compress&cs=tinysrgb&w=1600', category: 'basketball', alt: 'Basketball close-up' },
    { id: 5, src: 'https://images.pexels.com/photos/1618269/pexels-photo-1618269.jpeg?auto=compress&cs=tinysrgb&w=1600', category: 'handball', alt: 'Handball match' },
    { id: 6, src: 'https://images.pexels.com/photos/159698/referee-the-ball-game-competition-159698.jpeg?auto=compress&cs=tinysrgb&w=1600', category: 'other', alt: 'Sport referee' },
    { id: 7, src: 'https://images.pexels.com/photos/3621104/pexels-photo-3621104.jpeg?auto=compress&cs=tinysrgb&w=1600', category: 'football', alt: 'Football stadium' },
    { id: 8, src: 'https://images.pexels.com/photos/853199/pexels-photo-853199.jpeg?auto=compress&cs=tinysrgb&w=1600', category: 'basketball', alt: 'Basketball hoop' },
    { id: 9, src: 'https://images.pexels.com/photos/46798/the-ball-stadion-football-the-pitch-46798.jpeg?auto=compress&cs=tinysrgb&w=1600', category: 'football', alt: 'Soccer ball on field' },
    { id: 10, src: 'https://images.pexels.com/photos/2277923/pexels-photo-2277923.jpeg?auto=compress&cs=tinysrgb&w=1600', category: 'other', alt: 'Sports equipment' },
    { id: 11, src: 'https://images.pexels.com/photos/3148452/pexels-photo-3148452.jpeg?auto=compress&cs=tinysrgb&w=1600', category: 'basketball', alt: 'Basketball jump' },
    { id: 12, src: 'https://images.pexels.com/photos/3654861/pexels-photo-3654861.jpeg?auto=compress&cs=tinysrgb&w=1600', category: 'handball', alt: 'Handball player' }
  ];
  
  const filteredPhotos = selectedCategory === 'all' 
    ? photos 
    : photos.filter(photo => photo.category === selectedCategory);
  
  const openModal = (src: string) => {
    setModalImage(src);
    document.body.style.overflow = 'hidden';
  };
  
  const closeModal = () => {
    setModalImage(null);
    document.body.style.overflow = 'auto';
  };

  return (
    <>
      {/* Hero Section */}
      <section className="relative pt-20 pb-32 flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img
            src="https://images.pexels.com/photos/2468339/pexels-photo-2468339.jpeg?auto=compress&cs=tinysrgb&w=1600"
            alt="Photography Hero"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-black bg-opacity-60"></div>
        </div>
        
        <div className="container mx-auto px-4 relative z-10 text-center">
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-6 tracking-tight">
            Ma Galerie Photo
          </h1>
          <p className="text-xl text-gray-200 mb-6 max-w-2xl mx-auto">
            Découvrez ma collection de photographies sportives capturant des moments uniques
          </p>
          <div className="inline-flex items-center justify-center">
            <Camera size={24} className="text-blue-400 mr-2" />
            <span className="text-blue-400 font-medium">
              Plus de {photos.length} photos
            </span>
          </div>
        </div>
      </section>

      {/* Gallery Section */}
      <Section>
        {/* Filter Buttons */}
        <div className="flex flex-wrap justify-center gap-3 mb-12">
          {categories.map(category => (
            <button
              key={category.id}
              onClick={() => setSelectedCategory(category.id)}
              className={`
                px-5 py-2 rounded-full text-sm font-medium transition-all duration-200
                ${selectedCategory === category.id
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700'
                }
              `}
            >
              {category.name}
            </button>
          ))}
        </div>

        {/* Photo Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredPhotos.map(photo => (
            <div 
              key={photo.id} 
              className="relative group overflow-hidden rounded-lg shadow-md aspect-[4/3]"
              onClick={() => openModal(photo.src)}
            >
              <img 
                src={photo.src} 
                alt={photo.alt} 
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" 
              />
              <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-50 transition-all duration-300 flex items-center justify-center opacity-0 group-hover:opacity-100">
                <button 
                  className="p-3 bg-white rounded-full"
                  aria-label="Zoom in"
                >
                  <ZoomIn size={24} className="text-blue-600" />
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Empty State */}
        {filteredPhotos.length === 0 && (
          <div className="text-center py-20">
            <p className="text-gray-500 dark:text-gray-400 text-lg mb-4">
              Aucune photo trouvée dans cette catégorie.
            </p>
            <Button 
              onClick={() => setSelectedCategory('all')} 
              variant="outline"
            >
              Voir toutes les photos
            </Button>
          </div>
        )}
      </Section>

      {/* Modal */}
      {modalImage && (
        <div 
          className="fixed inset-0 z-50 bg-black bg-opacity-90 flex items-center justify-center p-4"
          onClick={closeModal}
        >
          <div className="relative max-w-6xl max-h-[90vh]">
            <button
              className="absolute -top-10 right-0 text-white hover:text-blue-400 transition-colors"
              onClick={closeModal}
              aria-label="Close modal"
            >
              Fermer
            </button>
            <img 
              src={modalImage} 
              alt="Full size" 
              className="max-w-full max-h-[80vh] object-contain"
              onClick={(e) => e.stopPropagation()}
            />
          </div>
        </div>
      )}
    </>
  );
};

export default Photos;