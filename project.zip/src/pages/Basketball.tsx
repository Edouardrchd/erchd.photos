import React from 'react';
import Section from '../components/ui/Section';
import Card, { CardImage, CardBody, CardTitle } from '../components/ui/Card';
import { Trophy, Camera, Award, Star } from 'lucide-react';

const Basketball: React.FC = () => {
  const teams = [
    {
      id: 1,
      name: "Paris Basketball",
      image: "https://images.pexels.com/photos/358042/pexels-photo-358042.jpeg?auto=compress&cs=tinysrgb&w=1600",
      description: "Collaboration régulière avec l'équipe professionnelle de Paris Basketball."
    },
    {
      id: 2,
      name: "ASVEL",
      image: "https://images.pexels.com/photos/853199/pexels-photo-853199.jpeg?auto=compress&cs=tinysrgb&w=1600",
      description: "Couverture des matchs à domicile de l'ASVEL en championnat de France."
    },
    {
      id: 3,
      name: "Monaco Basket",
      image: "https://images.pexels.com/photos/3148452/pexels-photo-3148452.jpeg?auto=compress&cs=tinysrgb&w=1600",
      description: "Reportages photos des matchs d'Euroleague de Monaco Basket."
    }
  ];

  const highlights = [
    { 
      title: "All-Star Game 2024", 
      icon: <Star size={40} className="text-orange-500" /> 
    },
    { 
      title: "Finale de la Coupe de France", 
      icon: <Trophy size={40} className="text-yellow-500" /> 
    },
    { 
      title: "Euroleague", 
      icon: <Award size={40} className="text-blue-500" /> 
    },
    { 
      title: "3x3 Championship", 
      icon: <Camera size={40} className="text-green-500" /> 
    }
  ];

  const photos = [
    "https://images.pexels.com/photos/358042/pexels-photo-358042.jpeg?auto=compress&cs=tinysrgb&w=1600",
    "https://images.pexels.com/photos/853199/pexels-photo-853199.jpeg?auto=compress&cs=tinysrgb&w=1600",
    "https://images.pexels.com/photos/3148452/pexels-photo-3148452.jpeg?auto=compress&cs=tinysrgb&w=1600",
    "https://images.pexels.com/photos/2824133/pexels-photo-2824133.jpeg?auto=compress&cs=tinysrgb&w=1600",
    "https://images.pexels.com/photos/945471/pexels-photo-945471.jpeg?auto=compress&cs=tinysrgb&w=1600",
    "https://images.pexels.com/photos/1080882/pexels-photo-1080882.jpeg?auto=compress&cs=tinysrgb&w=1600"
  ];

  return (
    <>
      {/* Hero Section */}
      <section className="relative pt-20 pb-32 flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img
            src="https://images.pexels.com/photos/358042/pexels-photo-358042.jpeg?auto=compress&cs=tinysrgb&w=1600"
            alt="Basketball Hero"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-black bg-opacity-70"></div>
        </div>
        
        <div className="container mx-auto px-4 relative z-10 text-center">
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-6 tracking-tight">
            Basketball
          </h1>
          <p className="text-xl text-gray-200 mb-6 max-w-2xl mx-auto">
            La magie du jeu capturée dans chaque cliché
          </p>
        </div>
      </section>

      {/* Introduction Section */}
      <Section>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div className="order-2 md:order-1">
            <h2 className="text-3xl font-bold mb-6 text-gray-900 dark:text-white">
              L'Art du Basketball en Images
            </h2>
            <p className="text-gray-700 dark:text-gray-300 mb-6 leading-relaxed">
              Le basketball est un sport d'élégance, de puissance et de précision. À travers mon objectif, 
              je cherche à capturer ces moments suspendus dans le temps : un dunk spectaculaire, 
              une passe décisive, ou l'intensité d'un regard concentré.
            </p>
            <p className="text-gray-700 dark:text-gray-300 mb-6 leading-relaxed">
              Ma passion pour ce sport m'a amené à collaborer avec plusieurs équipes professionnelles 
              et à couvrir des événements majeurs du basketball français et européen. Chaque match 
              est une nouvelle opportunité de raconter une histoire en images.
            </p>
            <div className="grid grid-cols-2 gap-6 mt-8">
              {highlights.map((highlight, index) => (
                <div key={index} className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-sm flex flex-col items-center text-center">
                  {highlight.icon}
                  <p className="mt-2 font-medium text-gray-800 dark:text-gray-200">
                    {highlight.title}
                  </p>
                </div>
              ))}
            </div>
          </div>
          <div className="order-1 md:order-2">
            <img 
              src="https://images.pexels.com/photos/2824133/pexels-photo-2824133.jpeg?auto=compress&cs=tinysrgb&w=1600" 
              alt="Basketball Photography"
              className="rounded-xl shadow-lg w-full h-auto object-cover" 
            />
          </div>
        </div>
      </Section>

      {/* Teams Section */}
      <Section title="Équipes Partenaires" className="bg-gray-50 dark:bg-gray-800">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {teams.map(team => (
            <Card key={team.id} hover>
              <CardImage src={team.image} alt={team.name} />
              <CardBody>
                <CardTitle>{team.name}</CardTitle>
                <p className="text-gray-600 dark:text-gray-400 mb-4">
                  {team.description}
                </p>
              </CardBody>
            </Card>
          ))}
        </div>
      </Section>

      {/* Photo Gallery */}
      <Section title="Galerie Basketball" subtitle="Une sélection de mes meilleures photos de basketball">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {photos.map((photo, index) => (
            <div key={index} className="overflow-hidden rounded-lg shadow-md transition-transform duration-300 hover:-translate-y-2 aspect-[4/3]">
              <img 
                src={photo} 
                alt={`Basketball photo ${index + 1}`} 
                className="w-full h-full object-cover transition-transform duration-500 hover:scale-110"
              />
            </div>
          ))}
        </div>
      </Section>

      {/* Quote Section */}
      <section className="py-24 bg-orange-500">
        <div className="container mx-auto px-4 text-center">
          <blockquote className="max-w-4xl mx-auto">
            <p className="text-2xl md:text-3xl text-white mb-8 italic">
              "Le basketball est un ballet de géants, où chaque mouvement raconte une histoire de détermination et de passion."
            </p>
            <footer className="text-orange-100">
              <cite>— À travers mon objectif</cite>
            </footer>
          </blockquote>
        </div>
      </section>
    </>
  );
};

export default Basketball;