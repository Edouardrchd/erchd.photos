import React from 'react';
import { ArrowRight } from 'lucide-react';
import Button from '../components/ui/Button';

const Home: React.FC = () => {
  const photos = [
    {
      src: "https://images.pexels.com/photos/46798/the-ball-stadion-football-the-pitch-46798.jpeg?auto=compress&cs=tinysrgb&w=1600",
      category: "Football",
      link: "/football"
    },
    {
      src: "https://images.pexels.com/photos/358042/pexels-photo-358042.jpeg?auto=compress&cs=tinysrgb&w=1600",
      category: "Basketball",
      link: "/basketball"
    },
    {
      src: "https://images.pexels.com/photos/3654861/pexels-photo-3654861.jpeg?auto=compress&cs=tinysrgb&w=1600",
      category: "Handball",
      link: "/handball"
    },
    {
      src: "https://images.pexels.com/photos/3148452/pexels-photo-3148452.jpeg?auto=compress&cs=tinysrgb&w=1600",
      category: "Basketball",
      link: "/basketball"
    },
    {
      src: "https://images.pexels.com/photos/853199/pexels-photo-853199.jpeg?auto=compress&cs=tinysrgb&w=1600",
      category: "Basketball",
      link: "/basketball"
    },
    {
      src: "https://images.pexels.com/photos/1618269/pexels-photo-1618269.jpeg?auto=compress&cs=tinysrgb&w=1600",
      category: "Handball",
      link: "/handball"
    }
  ];

  return (
    <main className="min-h-screen pt-20">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-0">
        {photos.map((photo, index) => (
          <div 
            key={index} 
            className="relative aspect-square group overflow-hidden cursor-pointer"
          >
            <img
              src={photo.src}
              alt={`${photo.category} photography`}
              className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
            />
            <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-50 transition-all duration-300 flex items-center justify-center">
              <div className="transform translate-y-full group-hover:translate-y-0 transition-transform duration-300">
                <Button
                  to={photo.link}
                  variant="primary"
                  className="bg-white/90 hover:bg-white text-blue-900"
                  icon={<ArrowRight size={20} />}
                  iconPosition="right"
                >
                  {photo.category}
                </Button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </main>
  );
};

export default Home;