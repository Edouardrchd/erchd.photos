import React from 'react';
import Section from '../components/ui/Section';
import Card, { CardImage, CardBody, CardTitle } from '../components/ui/Card';
import { Trophy, User, Calendar, MapPin } from 'lucide-react';

const Football: React.FC = () => {
  const events = [
    {
      id: 1,
      title: "Championnat National",
      image: "https://images.pexels.com/photos/47730/the-ball-stadion-football-the-pitch-47730.jpeg?auto=compress&cs=tinysrgb&w=1600",
      date: "12 Juin 2025",
      location: "Stade de France, Paris",
      description: "Couverture photographique des matchs du championnat national de football."
    },
    {
      id: 2,
      title: "Coupe de la Ligue",
      image: "https://images.pexels.com/photos/46798/the-ball-stadion-football-the-pitch-46798.jpeg?auto=compress&cs=tinysrgb&w=1600",
      date: "24 Juillet 2025",
      location: "Stade Vélodrome, Marseille",
      description: "Reportage photo exclusif des demi-finales de la Coupe de la Ligue."
    },
    {
      id: 3,
      title: "Match Amical International",
      image: "https://images.pexels.com/photos/3621104/pexels-photo-3621104.jpeg?auto=compress&cs=tinysrgb&w=1600",
      date: "3 Août 2025",
      location: "Parc des Princes, Paris",
      description: "Photographies du match amical entre la France et l'Espagne."
    }
  ];

  const achievements = [
    { 
      title: "Plus de 50 matchs couverts", 
      icon: <Trophy size={40} className="text-blue-600 dark:text-blue-400" /> 
    },
    { 
      title: "Collaboration avec 12 clubs", 
      icon: <User size={40} className="text-blue-600 dark:text-blue-400" /> 
    },
    { 
      title: "5 ans d'expérience", 
      icon: <Calendar size={40} className="text-blue-600 dark:text-blue-400" /> 
    },
    { 
      title: "Couverture nationale", 
      icon: <MapPin size={40} className="text-blue-600 dark:text-blue-400" /> 
    }
  ];

  const photos = [
    "https://images.pexels.com/photos/47730/the-ball-stadion-football-the-pitch-47730.jpeg?auto=compress&cs=tinysrgb&w=1600",
    "https://images.pexels.com/photos/3755440/pexels-photo-3755440.jpeg?auto=compress&cs=tinysrgb&w=1600",
    "https://images.pexels.com/photos/3621104/pexels-photo-3621104.jpeg?auto=compress&cs=tinysrgb&w=1600",
    "https://images.pexels.com/photos/46798/the-ball-stadion-football-the-pitch-46798.jpeg?auto=compress&cs=tinysrgb&w=1600",
    "https://images.pexels.com/photos/274506/pexels-photo-274506.jpeg?auto=compress&cs=tinysrgb&w=1600",
    "https://images.pexels.com/photos/114296/pexels-photo-114296.jpeg?auto=compress&cs=tinysrgb&w=1600"
  ];

  return (
    <>
      {/* Hero Section */}
      <section className="relative pt-20 pb-32 flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img
            src="https://images.pexels.com/photos/46798/the-ball-stadion-football-the-pitch-46798.jpeg?auto=compress&cs=tinysrgb&w=1600"
            alt="Football Hero"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-black bg-opacity-70"></div>
        </div>
        
        <div className="container mx-auto px-4 relative z-10 text-center">
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-6 tracking-tight">
            Football
          </h1>
          <p className="text-xl text-gray-200 mb-6 max-w-2xl mx-auto">
            Capturant l'émotion et l'intensité du terrain à travers mon objectif
          </p>
        </div>
      </section>

      {/* Introduction Section */}
      <Section>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div>
            <img 
              src="https://images.pexels.com/photos/3148452/pexels-photo-3148452.jpeg?auto=compress&cs=tinysrgb&w=1600" 
              alt="Football Photography"
              className="rounded-xl shadow-lg w-full h-auto object-cover" 
            />
          </div>
          <div>
            <h2 className="text-3xl font-bold mb-6 text-gray-900 dark:text-white">
              Ma Passion pour le Football
            </h2>
            <p className="text-gray-700 dark:text-gray-300 mb-6 leading-relaxed">
              Le football est plus qu'un sport pour moi, c'est une source d'inspiration continuelle. 
              Depuis plus de 5 ans, je parcours les stades pour capturer ces moments d'intensité, 
              d'émotion et de beauté que seul le football peut offrir.
            </p>
            <p className="text-gray-700 dark:text-gray-300 mb-6 leading-relaxed">
              Chaque match raconte une histoire unique, et mon objectif est de la partager à travers 
              mes photographies. De l'excitation des supporters aux actions décisives sur le terrain, 
              j'essaie de saisir l'essence même de ce sport universel.
            </p>
            <div className="grid grid-cols-2 gap-6 mt-8">
              {achievements.map((achievement, index) => (
                <div key={index} className="flex flex-col items-center text-center">
                  {achievement.icon}
                  <p className="mt-2 font-medium text-gray-800 dark:text-gray-200">
                    {achievement.title}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </Section>

      {/* Photo Gallery */}
      <Section title="Galerie Football" className="bg-gray-50 dark:bg-gray-800">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {photos.map((photo, index) => (
            <div key={index} className="overflow-hidden rounded-lg shadow-md transition-transform duration-300 hover:-translate-y-2 aspect-[4/3]">
              <img 
                src={photo} 
                alt={`Football photo ${index + 1}`} 
                className="w-full h-full object-cover transition-transform duration-500 hover:scale-110"
              />
            </div>
          ))}
        </div>
      </Section>

      {/* Events Section */}
      <Section title="Événements Football" subtitle="Découvrez les événements que j'ai couvert et ceux à venir">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {events.map(event => (
            <Card key={event.id} hover>
              <CardImage src={event.image} alt={event.title} />
              <CardBody>
                <CardTitle>{event.title}</CardTitle>
                <div className="mb-4 space-y-2">
                  <div className="flex items-center text-gray-600 dark:text-gray-400">
                    <Calendar size={16} className="mr-2" />
                    {event.date}
                  </div>
                  <div className="flex items-center text-gray-600 dark:text-gray-400">
                    <MapPin size={16} className="mr-2" />
                    {event.location}
                  </div>
                </div>
                <p className="text-gray-600 dark:text-gray-400 mb-4">
                  {event.description}
                </p>
              </CardBody>
            </Card>
          ))}
        </div>
      </Section>

      {/* Quote Section */}
      <section className="py-24 bg-blue-600 dark:bg-blue-800">
        <div className="container mx-auto px-4 text-center">
          <blockquote className="max-w-4xl mx-auto">
            <p className="text-2xl md:text-3xl text-white mb-8 italic">
              "Le football est comme un appareil photo - il capture des moments qui resteront figés dans le temps pour toujours."
            </p>
            <footer className="text-blue-200">
              <cite>— Mon approche de la photographie sportive</cite>
            </footer>
          </blockquote>
        </div>
      </section>
    </>
  );
};

export default Football;